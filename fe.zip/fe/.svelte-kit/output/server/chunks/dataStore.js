import { d as derived, w as writable } from "./index.js";
const currentUser = {
  id: "usr-001",
  name: "Ahmad Fauzi",
  email: "ahmad.fauzi@byond.co.id",
  role: "SUPER_ADMIN",
  avatar: ""
};
const customers$1 = [
  {
    id: "cust-001",
    companyName: "PT Astra International Tbk",
    city: "Jakarta",
    contactPerson: "Budi Santoso",
    email: "budi.santoso@astra.co.id",
    phone: "021-5089-1234",
    nb: "NB-001",
    npwp: "01.234.567.8-091.000",
    npwpAddress: "Jl. Gaya Motor Raya No.8, Sunter II, Jakarta Utara",
    address: "Jl. Gaya Motor Raya No.8, Sunter II, Jakarta Utara 14330",
    termOfPayment: 30,
    notes: "Pelanggan prioritas utama"
  },
  {
    id: "cust-002",
    companyName: "PT Telkom Indonesia Tbk",
    city: "Bandung",
    contactPerson: "Siti Rahayu",
    email: "siti.rahayu@telkom.co.id",
    phone: "022-4520-1111",
    nb: "NB-002",
    npwp: "01.345.678.9-423.000",
    npwpAddress: "Jl. Japati No.1, Bandung",
    address: "Jl. Japati No.1, Bandung, Jawa Barat 40133",
    termOfPayment: 45,
    notes: "Term pembayaran khusus 45 hari"
  },
  {
    id: "cust-003",
    companyName: "PT Pertamina (Persero)",
    city: "Jakarta",
    contactPerson: "Hendra Wijaya",
    email: "hendra.wijaya@pertamina.com",
    phone: "021-3815-9000",
    nb: "NB-003",
    npwp: "01.061.127.0-051.000",
    npwpAddress: "Jl. Medan Merdeka Timur No.1A, Jakarta Pusat",
    address: "Jl. Medan Merdeka Timur No.1A, Jakarta Pusat 10110",
    termOfPayment: 30,
    notes: "Kontrak tahunan"
  },
  {
    id: "cust-004",
    companyName: "PT Unilever Indonesia Tbk",
    city: "Tangerang",
    contactPerson: "Dewi Lestari",
    email: "dewi.lestari@unilever.com",
    phone: "021-5460-6000",
    nb: "NB-004",
    npwp: "01.078.219.5-054.000",
    npwpAddress: "Grha Unilever, BSD City, Tangerang",
    address: "Grha Unilever, Green Office Park Kav. 3, BSD City, Tangerang 15345",
    termOfPayment: 60,
    notes: "Pengiriman setiap Senin dan Kamis"
  },
  {
    id: "cust-005",
    companyName: "PT Bank Central Asia Tbk",
    city: "Jakarta",
    contactPerson: "Rizky Pratama",
    email: "rizky.pratama@bca.co.id",
    phone: "021-2358-8000",
    nb: "NB-005",
    npwp: "01.309.148.0-091.000",
    npwpAddress: "Menara BCA, Jl. MH Thamrin No.1, Jakarta Pusat",
    address: "Menara BCA, Grand Indonesia, Jl. MH Thamrin No.1, Jakarta Pusat 10310",
    termOfPayment: 30,
    notes: "Pembayaran via transfer BCA"
  }
];
const products$1 = [
  {
    id: "prod-001",
    name: "Kertas HVS A4 80gsm",
    category: "Alat Tulis Kantor",
    unit: "Rim",
    price: 65e3,
    stock: 500,
    description: "Kertas HVS ukuran A4, berat 80 gram per meter persegi, 500 lembar per rim"
  },
  {
    id: "prod-002",
    name: "Toner Printer HP LaserJet",
    category: "Perlengkapan IT",
    unit: "Unit",
    price: 125e4,
    stock: 50,
    description: "Toner cartridge original HP LaserJet Pro series, yield 2500 halaman"
  },
  {
    id: "prod-003",
    name: "Meja Kantor Direktur",
    category: "Furniture",
    unit: "Unit",
    price: 85e5,
    stock: 15,
    description: "Meja kantor eksekutif kayu jati solid, ukuran 180x90x75cm, laci 3 tingkat"
  },
  {
    id: "prod-004",
    name: "Kursi Ergonomis Mesh",
    category: "Furniture",
    unit: "Unit",
    price: 375e4,
    stock: 30,
    description: "Kursi kantor ergonomis dengan sandaran mesh, adjustable armrest dan lumbar support"
  },
  {
    id: "prod-005",
    name: "AC Split Daikin 2PK",
    category: "Elektronik",
    unit: "Unit",
    price: 125e5,
    stock: 10,
    description: "AC Split Daikin Inverter 2PK, hemat energi, garansi kompresor 10 tahun"
  }
];
const suppliers$1 = [
  {
    id: "sup-001",
    companyName: "CV Mitra Sejahtera",
    contactPerson: "Agus Priyanto",
    email: "agus@mitrasejahtera.co.id",
    phone: "021-6543-2100",
    address: "Jl. Mangga Dua Raya No.45, Jakarta Utara 14430",
    city: "Jakarta",
    npwp: "02.123.456.7-041.000"
  },
  {
    id: "sup-002",
    companyName: "PT Sumber Makmur Abadi",
    contactPerson: "Lina Kusuma",
    email: "lina@sumbermakmur.com",
    phone: "031-7891-2345",
    address: "Jl. Rungkut Industri Raya No.12, Surabaya 60293",
    city: "Surabaya",
    npwp: "02.234.567.8-631.000"
  },
  {
    id: "sup-003",
    companyName: "PT Jaya Abadi Teknik",
    contactPerson: "Tono Subroto",
    email: "tono@jayaabadi.co.id",
    phone: "022-8765-4321",
    address: "Jl. Soekarno-Hatta No.789, Bandung 40286",
    city: "Bandung",
    npwp: "02.345.678.9-423.000"
  },
  {
    id: "sup-004",
    companyName: "CV Karya Indah Furniture",
    contactPerson: "Wahyu Hidayat",
    email: "wahyu@karyaindah.com",
    phone: "0271-654-321",
    address: "Jl. Solo-Sragen KM 7, Karanganyar, Jawa Tengah 57711",
    city: "Solo",
    npwp: "02.456.789.0-526.000"
  },
  {
    id: "sup-005",
    companyName: "PT Nusantara Elektronik",
    contactPerson: "Rina Susanti",
    email: "rina@nusantaraelektronik.co.id",
    phone: "021-4567-8901",
    address: "Jl. Hayam Wuruk No.123, Glodok, Jakarta Barat 11180",
    city: "Jakarta",
    npwp: "02.567.890.1-034.000"
  }
];
const employees$1 = [
  {
    id: "emp-001",
    name: "Ahmad Fauzi",
    position: "General Manager",
    email: "ahmad.fauzi@byond.co.id",
    phone: "0812-3456-7890",
    address: "Jl. Kemang Raya No.12, Jakarta Selatan",
    status: "active"
  },
  {
    id: "emp-002",
    name: "Nurul Hidayah",
    position: "Accounting Manager",
    email: "nurul.hidayah@byond.co.id",
    phone: "0813-4567-8901",
    address: "Jl. Pondok Indah No.45, Jakarta Selatan",
    status: "active"
  },
  {
    id: "emp-003",
    name: "Reza Mahendra",
    position: "Sales Manager",
    email: "reza.mahendra@byond.co.id",
    phone: "0814-5678-9012",
    address: "Jl. Bintaro Jaya Sektor 9 Blok A5, Tangerang Selatan",
    status: "active"
  },
  {
    id: "emp-004",
    name: "Putri Anggraini",
    position: "Purchasing Staff",
    email: "putri.anggraini@byond.co.id",
    phone: "0815-6789-0123",
    address: "Perumahan Griya Asri Blok C No.7, Bekasi",
    status: "active"
  },
  {
    id: "emp-005",
    name: "Dedi Kurniawan",
    position: "Warehouse Staff",
    email: "dedi.kurniawan@byond.co.id",
    phone: "0816-7890-1234",
    address: "Jl. Ciputat Raya No.88, Tangerang Selatan",
    status: "inactive"
  }
];
const chartOfAccounts$1 = [
  { id: "coa-001", code: "1-1000", name: "Kas", category: "Asset", balance: 25e7 },
  { id: "coa-002", code: "1-2000", name: "Bank BCA", category: "Asset", balance: 185e7 },
  { id: "coa-003", code: "1-3000", name: "Piutang Usaha", category: "Asset", balance: 475e6 },
  { id: "coa-004", code: "2-1000", name: "Hutang Usaha", category: "Liability", balance: 32e7 },
  { id: "coa-005", code: "2-2000", name: "Hutang Pajak", category: "Liability", balance: 85e6 },
  { id: "coa-006", code: "3-1000", name: "Modal Disetor", category: "Equity", balance: 2e9 },
  { id: "coa-007", code: "4-1000", name: "Pendapatan Penjualan", category: "Revenue", balance: 325e7 },
  { id: "coa-008", code: "5-1000", name: "Beban Pokok Penjualan", category: "Expense", balance: 195e7 }
];
const quotations$1 = [
  {
    id: "quo-001",
    date: "2024-01-15",
    quotationNo: "QUO/2024/001",
    transactionNo: "TRX/2024/001",
    customerId: "cust-001",
    customerName: "PT Astra International Tbk",
    preparedBy: "Ahmad Fauzi",
    salesPerson: "Reza Mahendra",
    status: "completed",
    items: [
      { id: "qi-001", productId: "prod-001", productName: "Kertas HVS A4 80gsm", quantity: 100, unit: "Rim", unitPrice: 65e3, discount: 5, total: 6175e3 },
      { id: "qi-002", productId: "prod-002", productName: "Toner Printer HP LaserJet", quantity: 20, unit: "Unit", unitPrice: 125e4, discount: 0, total: 25e6 }
    ],
    subtotal: 31175e3,
    tax: 3117500,
    total: 34292500,
    notes: "Pengiriman bertahap 2 kali"
  },
  {
    id: "quo-002",
    date: "2024-02-03",
    quotationNo: "QUO/2024/002",
    transactionNo: "TRX/2024/002",
    customerId: "cust-002",
    customerName: "PT Telkom Indonesia Tbk",
    preparedBy: "Ahmad Fauzi",
    salesPerson: "Reza Mahendra",
    status: "sales",
    items: [
      { id: "qi-003", productId: "prod-003", productName: "Meja Kantor Direktur", quantity: 5, unit: "Unit", unitPrice: 85e5, discount: 10, total: 3825e4 },
      { id: "qi-004", productId: "prod-004", productName: "Kursi Ergonomis Mesh", quantity: 10, unit: "Unit", unitPrice: 375e4, discount: 5, total: 35625e3 }
    ],
    subtotal: 73875e3,
    tax: 7387500,
    total: 81262500,
    notes: "Untuk renovasi kantor cabang Bandung"
  },
  {
    id: "quo-003",
    date: "2024-02-20",
    quotationNo: "QUO/2024/003",
    transactionNo: "TRX/2024/003",
    customerId: "cust-003",
    customerName: "PT Pertamina (Persero)",
    preparedBy: "Ahmad Fauzi",
    salesPerson: "Reza Mahendra",
    status: "quotation",
    items: [
      { id: "qi-005", productId: "prod-005", productName: "AC Split Daikin 2PK", quantity: 8, unit: "Unit", unitPrice: 125e5, discount: 8, total: 92e6 }
    ],
    subtotal: 92e6,
    tax: 92e5,
    total: 1012e5,
    notes: "Pemasangan di gedung baru lantai 5-8"
  },
  {
    id: "quo-004",
    date: "2024-03-05",
    quotationNo: "QUO/2024/004",
    transactionNo: "TRX/2024/004",
    customerId: "cust-004",
    customerName: "PT Unilever Indonesia Tbk",
    preparedBy: "Nurul Hidayah",
    salesPerson: "Reza Mahendra",
    status: "completed",
    items: [
      { id: "qi-006", productId: "prod-001", productName: "Kertas HVS A4 80gsm", quantity: 200, unit: "Rim", unitPrice: 65e3, discount: 10, total: 117e5 },
      { id: "qi-007", productId: "prod-002", productName: "Toner Printer HP LaserJet", quantity: 30, unit: "Unit", unitPrice: 125e4, discount: 5, total: 35625e3 }
    ],
    subtotal: 47325e3,
    tax: 4732500,
    total: 52057500,
    notes: "Pesanan bulanan rutin"
  },
  {
    id: "quo-005",
    date: "2024-03-18",
    quotationNo: "QUO/2024/005",
    transactionNo: "TRX/2024/005",
    customerId: "cust-005",
    customerName: "PT Bank Central Asia Tbk",
    preparedBy: "Nurul Hidayah",
    salesPerson: "Reza Mahendra",
    status: "sales",
    items: [
      { id: "qi-008", productId: "prod-003", productName: "Meja Kantor Direktur", quantity: 3, unit: "Unit", unitPrice: 85e5, discount: 0, total: 255e5 },
      { id: "qi-009", productId: "prod-004", productName: "Kursi Ergonomis Mesh", quantity: 20, unit: "Unit", unitPrice: 375e4, discount: 10, total: 675e5 },
      { id: "qi-010", productId: "prod-005", productName: "AC Split Daikin 2PK", quantity: 4, unit: "Unit", unitPrice: 125e5, discount: 5, total: 475e5 }
    ],
    subtotal: 1405e5,
    tax: 1405e4,
    total: 15455e4,
    notes: "Untuk kantor cabang baru di Surabaya"
  }
];
const salesOrders$1 = [
  {
    id: "so-001",
    date: "2024-01-20",
    salesNo: "SO/2024/001",
    transactionNo: "TRX/2024/001",
    customerId: "cust-001",
    customerName: "PT Astra International Tbk",
    preparedBy: "Ahmad Fauzi",
    items: [
      { id: "si-001", productId: "prod-001", productName: "Kertas HVS A4 80gsm", quantity: 100, unit: "Rim", unitPrice: 65e3, discount: 5, total: 6175e3 },
      { id: "si-002", productId: "prod-002", productName: "Toner Printer HP LaserJet", quantity: 20, unit: "Unit", unitPrice: 125e4, discount: 0, total: 25e6 }
    ],
    subtotal: 31175e3,
    tax: 3117500,
    total: 34292500,
    status: "completed"
  },
  {
    id: "so-002",
    date: "2024-02-10",
    salesNo: "SO/2024/002",
    transactionNo: "TRX/2024/002",
    customerId: "cust-002",
    customerName: "PT Telkom Indonesia Tbk",
    preparedBy: "Ahmad Fauzi",
    items: [
      { id: "si-003", productId: "prod-003", productName: "Meja Kantor Direktur", quantity: 5, unit: "Unit", unitPrice: 85e5, discount: 10, total: 3825e4 },
      { id: "si-004", productId: "prod-004", productName: "Kursi Ergonomis Mesh", quantity: 10, unit: "Unit", unitPrice: 375e4, discount: 5, total: 35625e3 }
    ],
    subtotal: 73875e3,
    tax: 7387500,
    total: 81262500,
    status: "delivered"
  },
  {
    id: "so-003",
    date: "2024-03-01",
    salesNo: "SO/2024/003",
    transactionNo: "TRX/2024/004",
    customerId: "cust-004",
    customerName: "PT Unilever Indonesia Tbk",
    preparedBy: "Nurul Hidayah",
    items: [
      { id: "si-005", productId: "prod-001", productName: "Kertas HVS A4 80gsm", quantity: 200, unit: "Rim", unitPrice: 65e3, discount: 10, total: 117e5 },
      { id: "si-006", productId: "prod-002", productName: "Toner Printer HP LaserJet", quantity: 30, unit: "Unit", unitPrice: 125e4, discount: 5, total: 35625e3 }
    ],
    subtotal: 47325e3,
    tax: 4732500,
    total: 52057500,
    status: "completed"
  },
  {
    id: "so-004",
    date: "2024-03-20",
    salesNo: "SO/2024/004",
    transactionNo: "TRX/2024/005",
    customerId: "cust-005",
    customerName: "PT Bank Central Asia Tbk",
    preparedBy: "Nurul Hidayah",
    items: [
      { id: "si-007", productId: "prod-003", productName: "Meja Kantor Direktur", quantity: 3, unit: "Unit", unitPrice: 85e5, discount: 0, total: 255e5 },
      { id: "si-008", productId: "prod-004", productName: "Kursi Ergonomis Mesh", quantity: 20, unit: "Unit", unitPrice: 375e4, discount: 10, total: 675e5 }
    ],
    subtotal: 93e6,
    tax: 93e5,
    total: 1023e5,
    status: "pending"
  },
  {
    id: "so-005",
    date: "2024-04-02",
    salesNo: "SO/2024/005",
    transactionNo: "TRX/2024/006",
    customerId: "cust-003",
    customerName: "PT Pertamina (Persero)",
    preparedBy: "Ahmad Fauzi",
    items: [
      { id: "si-009", productId: "prod-005", productName: "AC Split Daikin 2PK", quantity: 6, unit: "Unit", unitPrice: 125e5, discount: 5, total: 7125e4 }
    ],
    subtotal: 7125e4,
    tax: 7125e3,
    total: 78375e3,
    status: "pending"
  }
];
const purchaseOrders$1 = [
  {
    id: "po-001",
    date: "2024-01-10",
    purchaseNo: "PO/2024/001",
    transactionNo: "TRX-PO/2024/001",
    supplierId: "sup-001",
    supplierName: "CV Mitra Sejahtera",
    preparedBy: "Putri Anggraini",
    items: [
      { id: "pi-001", productId: "prod-001", productName: "Kertas HVS A4 80gsm", quantity: 300, unit: "Rim", unitPrice: 48e3, discount: 0, total: 144e5 }
    ],
    subtotal: 144e5,
    tax: 144e4,
    total: 1584e4,
    status: "completed"
  },
  {
    id: "po-002",
    date: "2024-01-25",
    purchaseNo: "PO/2024/002",
    transactionNo: "TRX-PO/2024/002",
    supplierId: "sup-002",
    supplierName: "PT Sumber Makmur Abadi",
    preparedBy: "Putri Anggraini",
    items: [
      { id: "pi-002", productId: "prod-002", productName: "Toner Printer HP LaserJet", quantity: 50, unit: "Unit", unitPrice: 85e4, discount: 5, total: 40375e3 }
    ],
    subtotal: 40375e3,
    tax: 4037500,
    total: 44412500,
    status: "received"
  },
  {
    id: "po-003",
    date: "2024-02-15",
    purchaseNo: "PO/2024/003",
    transactionNo: "TRX-PO/2024/003",
    supplierId: "sup-004",
    supplierName: "CV Karya Indah Furniture",
    preparedBy: "Putri Anggraini",
    items: [
      { id: "pi-003", productId: "prod-003", productName: "Meja Kantor Direktur", quantity: 10, unit: "Unit", unitPrice: 55e5, discount: 0, total: 55e6 },
      { id: "pi-004", productId: "prod-004", productName: "Kursi Ergonomis Mesh", quantity: 30, unit: "Unit", unitPrice: 24e5, discount: 10, total: 648e5 }
    ],
    subtotal: 1198e5,
    tax: 1198e4,
    total: 13178e4,
    status: "completed"
  },
  {
    id: "po-004",
    date: "2024-03-10",
    purchaseNo: "PO/2024/004",
    transactionNo: "TRX-PO/2024/004",
    supplierId: "sup-005",
    supplierName: "PT Nusantara Elektronik",
    preparedBy: "Putri Anggraini",
    items: [
      { id: "pi-005", productId: "prod-005", productName: "AC Split Daikin 2PK", quantity: 15, unit: "Unit", unitPrice: 82e5, discount: 5, total: 11685e4 }
    ],
    subtotal: 11685e4,
    tax: 11685e3,
    total: 128535e3,
    status: "pending"
  },
  {
    id: "po-005",
    date: "2024-03-28",
    purchaseNo: "PO/2024/005",
    transactionNo: "TRX-PO/2024/005",
    supplierId: "sup-003",
    supplierName: "PT Jaya Abadi Teknik",
    preparedBy: "Putri Anggraini",
    items: [
      { id: "pi-006", productId: "prod-001", productName: "Kertas HVS A4 80gsm", quantity: 500, unit: "Rim", unitPrice: 46e3, discount: 3, total: 2231e4 },
      { id: "pi-007", productId: "prod-002", productName: "Toner Printer HP LaserJet", quantity: 25, unit: "Unit", unitPrice: 83e4, discount: 0, total: 2075e4 }
    ],
    subtotal: 4306e4,
    tax: 4306e3,
    total: 47366e3,
    status: "pending"
  }
];
const deliveries$1 = [
  {
    id: "del-001",
    date: "2024-01-25",
    deliveryNo: "DO/2024/001",
    salesNo: "SO/2024/001",
    transactionNo: "TRX/2024/001",
    customerName: "PT Astra International Tbk",
    preparedBy: "Dedi Kurniawan",
    items: [
      { id: "di-001", productId: "prod-001", productName: "Kertas HVS A4 80gsm", quantity: 100, unit: "Rim", unitPrice: 65e3, discount: 5, total: 6175e3 },
      { id: "di-002", productId: "prod-002", productName: "Toner Printer HP LaserJet", quantity: 20, unit: "Unit", unitPrice: 125e4, discount: 0, total: 25e6 }
    ],
    status: "delivered"
  },
  {
    id: "del-002",
    date: "2024-02-18",
    deliveryNo: "DO/2024/002",
    salesNo: "SO/2024/002",
    transactionNo: "TRX/2024/002",
    customerName: "PT Telkom Indonesia Tbk",
    preparedBy: "Dedi Kurniawan",
    items: [
      { id: "di-003", productId: "prod-003", productName: "Meja Kantor Direktur", quantity: 5, unit: "Unit", unitPrice: 85e5, discount: 10, total: 3825e4 }
    ],
    status: "delivered"
  },
  {
    id: "del-003",
    date: "2024-02-20",
    deliveryNo: "DO/2024/003",
    salesNo: "SO/2024/002",
    transactionNo: "TRX/2024/002",
    customerName: "PT Telkom Indonesia Tbk",
    preparedBy: "Dedi Kurniawan",
    items: [
      { id: "di-004", productId: "prod-004", productName: "Kursi Ergonomis Mesh", quantity: 10, unit: "Unit", unitPrice: 375e4, discount: 5, total: 35625e3 }
    ],
    status: "shipped"
  },
  {
    id: "del-004",
    date: "2024-03-08",
    deliveryNo: "DO/2024/004",
    salesNo: "SO/2024/003",
    transactionNo: "TRX/2024/004",
    customerName: "PT Unilever Indonesia Tbk",
    preparedBy: "Dedi Kurniawan",
    items: [
      { id: "di-005", productId: "prod-001", productName: "Kertas HVS A4 80gsm", quantity: 200, unit: "Rim", unitPrice: 65e3, discount: 10, total: 117e5 },
      { id: "di-006", productId: "prod-002", productName: "Toner Printer HP LaserJet", quantity: 30, unit: "Unit", unitPrice: 125e4, discount: 5, total: 35625e3 }
    ],
    status: "delivered"
  },
  {
    id: "del-005",
    date: "2024-03-25",
    deliveryNo: "DO/2024/005",
    salesNo: "SO/2024/004",
    transactionNo: "TRX/2024/005",
    customerName: "PT Bank Central Asia Tbk",
    preparedBy: "Dedi Kurniawan",
    items: [
      { id: "di-007", productId: "prod-003", productName: "Meja Kantor Direktur", quantity: 3, unit: "Unit", unitPrice: 85e5, discount: 0, total: 255e5 }
    ],
    status: "pending"
  }
];
const goodsReceipts$1 = [
  {
    id: "gr-001",
    date: "2024-01-15",
    receiptNo: "GR/2024/001",
    purchaseNo: "PO/2024/001",
    transactionNo: "TRX-PO/2024/001",
    supplierName: "CV Mitra Sejahtera",
    preparedBy: "Dedi Kurniawan",
    items: [
      { id: "gi-001", productId: "prod-001", productName: "Kertas HVS A4 80gsm", quantity: 300, unit: "Rim", unitPrice: 48e3, discount: 0, total: 144e5 }
    ],
    status: "received"
  },
  {
    id: "gr-002",
    date: "2024-02-01",
    receiptNo: "GR/2024/002",
    purchaseNo: "PO/2024/002",
    transactionNo: "TRX-PO/2024/002",
    supplierName: "PT Sumber Makmur Abadi",
    preparedBy: "Dedi Kurniawan",
    items: [
      { id: "gi-002", productId: "prod-002", productName: "Toner Printer HP LaserJet", quantity: 50, unit: "Unit", unitPrice: 85e4, discount: 5, total: 40375e3 }
    ],
    status: "received"
  },
  {
    id: "gr-003",
    date: "2024-02-28",
    receiptNo: "GR/2024/003",
    purchaseNo: "PO/2024/003",
    transactionNo: "TRX-PO/2024/003",
    supplierName: "CV Karya Indah Furniture",
    preparedBy: "Dedi Kurniawan",
    items: [
      { id: "gi-003", productId: "prod-003", productName: "Meja Kantor Direktur", quantity: 10, unit: "Unit", unitPrice: 55e5, discount: 0, total: 55e6 },
      { id: "gi-004", productId: "prod-004", productName: "Kursi Ergonomis Mesh", quantity: 30, unit: "Unit", unitPrice: 24e5, discount: 10, total: 648e5 }
    ],
    status: "received"
  },
  {
    id: "gr-004",
    date: "2024-03-15",
    receiptNo: "GR/2024/004",
    purchaseNo: "PO/2024/004",
    transactionNo: "TRX-PO/2024/004",
    supplierName: "PT Nusantara Elektronik",
    preparedBy: "Dedi Kurniawan",
    items: [
      { id: "gi-005", productId: "prod-005", productName: "AC Split Daikin 2PK", quantity: 15, unit: "Unit", unitPrice: 82e5, discount: 5, total: 11685e4 }
    ],
    status: "pending"
  },
  {
    id: "gr-005",
    date: "2024-04-05",
    receiptNo: "GR/2024/005",
    purchaseNo: "PO/2024/005",
    transactionNo: "TRX-PO/2024/005",
    supplierName: "PT Jaya Abadi Teknik",
    preparedBy: "Dedi Kurniawan",
    items: [
      { id: "gi-006", productId: "prod-001", productName: "Kertas HVS A4 80gsm", quantity: 500, unit: "Rim", unitPrice: 46e3, discount: 3, total: 2231e4 }
    ],
    status: "pending"
  }
];
const payments$1 = [
  {
    id: "pay-001",
    date: "2024-02-15",
    paymentNo: "PAY/2024/001",
    transactionNo: "TRX/2024/001",
    customerName: "PT Astra International Tbk",
    invoiceNo: "INV/2024/001",
    amount: 34292500,
    method: "transfer",
    status: "paid",
    preparedBy: "Nurul Hidayah"
  },
  {
    id: "pay-002",
    date: "2024-03-20",
    paymentNo: "PAY/2024/002",
    transactionNo: "TRX/2024/002",
    customerName: "PT Telkom Indonesia Tbk",
    invoiceNo: "INV/2024/002",
    amount: 40631250,
    method: "transfer",
    status: "paid",
    preparedBy: "Nurul Hidayah"
  },
  {
    id: "pay-003",
    date: "2024-03-28",
    paymentNo: "PAY/2024/003",
    transactionNo: "TRX/2024/002",
    customerName: "PT Telkom Indonesia Tbk",
    invoiceNo: "INV/2024/003",
    amount: 40631250,
    method: "check",
    status: "pending",
    preparedBy: "Nurul Hidayah"
  },
  {
    id: "pay-004",
    date: "2024-04-05",
    paymentNo: "PAY/2024/004",
    transactionNo: "TRX/2024/004",
    customerName: "PT Unilever Indonesia Tbk",
    invoiceNo: "INV/2024/004",
    amount: 52057500,
    method: "transfer",
    status: "paid",
    preparedBy: "Nurul Hidayah"
  },
  {
    id: "pay-005",
    date: "2024-04-15",
    paymentNo: "PAY/2024/005",
    transactionNo: "TRX/2024/005",
    customerName: "PT Bank Central Asia Tbk",
    invoiceNo: "INV/2024/005",
    amount: 1023e5,
    method: "transfer",
    status: "pending",
    preparedBy: "Nurul Hidayah"
  }
];
const billPayments$1 = [
  {
    id: "bp-001",
    date: "2024-02-10",
    billNo: "BP/2024/001",
    transactionNo: "TRX-PO/2024/001",
    supplierName: "CV Mitra Sejahtera",
    invoiceNo: "VINV/2024/001",
    amount: 1584e4,
    method: "transfer",
    status: "paid",
    preparedBy: "Nurul Hidayah"
  },
  {
    id: "bp-002",
    date: "2024-02-25",
    billNo: "BP/2024/002",
    transactionNo: "TRX-PO/2024/002",
    supplierName: "PT Sumber Makmur Abadi",
    invoiceNo: "VINV/2024/002",
    amount: 44412500,
    method: "transfer",
    status: "paid",
    preparedBy: "Nurul Hidayah"
  },
  {
    id: "bp-003",
    date: "2024-03-15",
    billNo: "BP/2024/003",
    transactionNo: "TRX-PO/2024/003",
    supplierName: "CV Karya Indah Furniture",
    invoiceNo: "VINV/2024/003",
    amount: 6589e4,
    method: "transfer",
    status: "paid",
    preparedBy: "Nurul Hidayah"
  },
  {
    id: "bp-004",
    date: "2024-03-30",
    billNo: "BP/2024/004",
    transactionNo: "TRX-PO/2024/003",
    supplierName: "CV Karya Indah Furniture",
    invoiceNo: "VINV/2024/004",
    amount: 6589e4,
    method: "check",
    status: "pending",
    preparedBy: "Nurul Hidayah"
  },
  {
    id: "bp-005",
    date: "2024-04-10",
    billNo: "BP/2024/005",
    transactionNo: "TRX-PO/2024/004",
    supplierName: "PT Nusantara Elektronik",
    invoiceNo: "VINV/2024/005",
    amount: 128535e3,
    method: "transfer",
    status: "pending",
    preparedBy: "Nurul Hidayah"
  }
];
const debtPayments$1 = [
  {
    id: "dp-001",
    date: "2024-02-10",
    paymentNo: "DP/2024/001",
    transactionNo: "TRX-PO/2024/001",
    supplierName: "CV Mitra Sejahtera",
    purchaseNo: "PO/2024/001",
    amount: 1584e4,
    method: "transfer",
    status: "paid",
    preparedBy: "Nurul Hidayah"
  },
  {
    id: "dp-002",
    date: "2024-02-28",
    paymentNo: "DP/2024/002",
    transactionNo: "TRX-PO/2024/002",
    supplierName: "PT Sumber Makmur Abadi",
    purchaseNo: "PO/2024/002",
    amount: 44412500,
    method: "transfer",
    status: "paid",
    preparedBy: "Nurul Hidayah"
  },
  {
    id: "dp-003",
    date: "2024-03-20",
    paymentNo: "DP/2024/003",
    transactionNo: "TRX-PO/2024/003",
    supplierName: "CV Karya Indah Furniture",
    purchaseNo: "PO/2024/003",
    amount: 13178e4,
    method: "transfer",
    status: "paid",
    preparedBy: "Nurul Hidayah"
  },
  {
    id: "dp-004",
    date: "2024-04-05",
    paymentNo: "DP/2024/004",
    transactionNo: "TRX-PO/2024/004",
    supplierName: "PT Nusantara Elektronik",
    purchaseNo: "PO/2024/004",
    amount: 128535e3,
    method: "transfer",
    status: "pending",
    preparedBy: "Nurul Hidayah"
  },
  {
    id: "dp-005",
    date: "2024-04-15",
    paymentNo: "DP/2024/005",
    transactionNo: "TRX-PO/2024/005",
    supplierName: "PT Jaya Abadi Teknik",
    purchaseNo: "PO/2024/005",
    amount: 47366e3,
    method: "check",
    status: "pending",
    preparedBy: "Nurul Hidayah"
  }
];
const journalEntries$1 = [
  {
    id: "je-001",
    date: "2024-01-20",
    description: "Penjualan kepada PT Astra International Tbk",
    debitAccount: "1-3000 Piutang Usaha",
    creditAccount: "4-1000 Pendapatan Penjualan",
    amount: 34292500,
    reference: "SO/2024/001"
  },
  {
    id: "je-002",
    date: "2024-01-10",
    description: "Pembelian kertas dari CV Mitra Sejahtera",
    debitAccount: "5-1000 Beban Pokok Penjualan",
    creditAccount: "2-1000 Hutang Usaha",
    amount: 1584e4,
    reference: "PO/2024/001"
  },
  {
    id: "je-003",
    date: "2024-02-10",
    description: "Pembayaran hutang kepada CV Mitra Sejahtera",
    debitAccount: "2-1000 Hutang Usaha",
    creditAccount: "1-2000 Bank BCA",
    amount: 1584e4,
    reference: "DP/2024/001"
  },
  {
    id: "je-004",
    date: "2024-02-15",
    description: "Penerimaan pembayaran dari PT Astra International Tbk",
    debitAccount: "1-2000 Bank BCA",
    creditAccount: "1-3000 Piutang Usaha",
    amount: 34292500,
    reference: "PAY/2024/001"
  },
  {
    id: "je-005",
    date: "2024-03-01",
    description: "Penjualan kepada PT Unilever Indonesia Tbk",
    debitAccount: "1-3000 Piutang Usaha",
    creditAccount: "4-1000 Pendapatan Penjualan",
    amount: 52057500,
    reference: "SO/2024/003"
  }
];
const appSettings$1 = {
  companyName: "PT Byond Technology Indonesia",
  companyAddress: "Jl. Jend. Sudirman Kav 52-53, Jakarta Selatan 12190",
  companyPhone: "021-515-3456",
  companyEmail: "info@byond.co.id",
  companyNpwp: "01.987.654.3-091.000",
  currency: "IDR",
  taxRate: 11
};
const customers = writable(customers$1);
const products = writable(products$1);
const suppliers = writable(suppliers$1);
const employees = writable(employees$1);
const chartOfAccounts = writable(chartOfAccounts$1);
const quotations = writable(quotations$1);
const salesOrders = writable(salesOrders$1);
const purchaseOrders = writable(purchaseOrders$1);
const goodsReceipts = writable(goodsReceipts$1);
const deliveries = writable(deliveries$1);
const billPayments = writable(billPayments$1);
const payments = writable(payments$1);
const debtPayments = writable(debtPayments$1);
const journalEntries = writable(journalEntries$1);
const appSettings = writable(appSettings$1);
const systemAlerts = writable([
  {
    id: "alt-001",
    title: "Jatuh Tempo Hutang PO/2024/001",
    message: "Pemberitahuan: Anda memiliki tagihan hutang vendor sebesar Rp 15.840.000 yang mendekati jatuh tempo.",
    type: "debt",
    referenceNo: "PO/2024/001",
    link: "/debt-payment",
    date: "2024-04-10",
    read: false
  },
  {
    id: "alt-002",
    title: "Peringatan Piutang INV/2024/002",
    message: "Pemberitahuan: Piutang usaha PT Telkom Indonesia sebesar Rp 142.080.000 belum lunas.",
    type: "receivable",
    referenceNo: "INV/2024/002",
    link: "/bill",
    date: "2024-04-12",
    read: false
  },
  {
    id: "alt-003",
    title: "Penagihan Tertunda SO/2024/005",
    message: "Delivery selesai, siap diterbitkan tagihan invoice penagihan ke customer.",
    type: "info",
    referenceNo: "SO/2024/005",
    link: "/bill",
    date: "2024-04-14",
    read: false
  }
]);
const totalSalesAmount = derived(
  salesOrders,
  ($sales) => $sales.reduce((sum, so) => sum + so.total, 0)
);
const totalReceivableAmount = derived(
  billPayments,
  ($bills) => $bills.filter((b) => b.status === "pending").reduce((sum, b) => sum + b.amount, 0)
);
const totalPayableAmount = derived(
  purchaseOrders,
  ($po) => $po.filter((p) => p.status === "pending").reduce((sum, p) => sum + p.total, 0)
);
const paymentCompletionRate = derived(
  [billPayments, payments],
  ([$bills, $payments]) => {
    const totalBilled = $bills.reduce((sum, b) => sum + b.amount, 0);
    const totalPaid = $payments.reduce((sum, p) => sum + p.amount, 0);
    if (totalBilled === 0) return 100;
    return Math.min(100, Math.round(totalPaid / totalBilled * 100));
  }
);
export {
  appSettings as a,
  salesOrders as b,
  billPayments as c,
  chartOfAccounts as d,
  customers as e,
  totalReceivableAmount as f,
  totalPayableAmount as g,
  payments as h,
  deliveries as i,
  goodsReceipts as j,
  purchaseOrders as k,
  debtPayments as l,
  employees as m,
  products as n,
  suppliers as o,
  paymentCompletionRate as p,
  quotations as q,
  journalEntries as r,
  systemAlerts as s,
  totalSalesAmount as t,
  currentUser as u
};
